from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

file_path = "D:/medical_llm/data/sample.pdf"

styles = getSampleStyleSheet()
doc = SimpleDocTemplate(file_path)

content = []

content.append(Paragraph("Patient Name: Ravi Kumar", styles["Normal"]))
content.append(Spacer(1, 10))
content.append(Paragraph("Diagnosis: Type 2 Diabetes", styles["Normal"]))
content.append(Spacer(1, 10))
content.append(Paragraph("Medication: Metformin 500mg twice daily", styles["Normal"]))
content.append(Spacer(1, 10))
content.append(Paragraph("Advice: Exercise regularly", styles["Normal"]))

doc.build(content)

print("PDF created successfully!")